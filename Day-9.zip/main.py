a = int(input('Enter Your Age: '))
print("")
print("Your age is :",a) 
print("")
# Conditional operators 
# >, <, >=, <=, ==, !=
print(a>18)  # Greater than 'a' 
print(a<18)  # Less than 'a'
print(a>=18) # Greater than or Equal to 'a'
print(a<=18) # Less than or Equal to 'a'
print(a==18) # Accurately Equal to 'a'
print(a!=18) # Not Equal to 'a'



print("")

if(a>20):
  print ("You can go there")
else:
  print('You cannot go there')